/* 
 * File:   main.cpp
 * Author: Huiyi Zhong
 * Created on February 27, 2017, 4:00 PM
 * Purpose:  Homework chp2 Q14
 *            
 *          
 */

//System Libraries
#include <iostream> 
#include <string>
using namespace std;


int main(int argc, char** argv) 
{
    cout<< "Name: Huiyi Zhong"<<endl;
    cout<< "Address: 1378 Cresta Rd, Corona, CA 92879"<< endl;
    cout<< "Telephone number: (123)456-7890"<< endl;
    cout<< "College major: Mechanical Engineering"<< endl;
          
    
    return 0;
}