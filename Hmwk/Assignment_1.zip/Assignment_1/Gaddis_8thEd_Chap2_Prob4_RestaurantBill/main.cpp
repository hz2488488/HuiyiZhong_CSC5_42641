/* 
 * File:   main.cpp
 * Author: Huiyi Zhong
 * Created on February 27, 2017, 4:00 PM
 * Purpose:  Homework chp2 Q4
 *            
 *          
 */

//System Libraries
#include <iostream> 
using namespace std;


int main(int argc, char** argv) 
{
   double taxPercent = 0.0675;
   double tipPercent = 0.20;
   double mealCost = 88.67;
   double tax, tip, totalBill;
   // calculations of tax and tips:
   tax = taxPercent * mealCost;
   tip = tipPercent * mealCost + tipPercent * tax;
   // calculations of total meal cost
   totalBill = mealCost + tip + tax;
   cout<< "Meal cost:$"<< mealCost << endl;
   cout<< "Tax amount:$" << tax << endl;
   cout<< "Tip amount:$" << tip << endl;
   cout<< "total bill amount:$" << totalBill << endl;
    return 0;
}

