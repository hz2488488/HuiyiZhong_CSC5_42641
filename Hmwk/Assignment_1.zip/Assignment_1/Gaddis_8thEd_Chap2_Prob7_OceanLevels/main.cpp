/* 
 * File:   main.cpp
 * Author: Huiyi Zhong
 * Created on February 28, 2017, 10:45 AM
 * Purpose:  Homework of chpt2 Q7
 *           
 *          
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

int main(int argc, char** argv) 
{
    double risingMMPerYear, fiveYears, sevenYears, tenYears;
    risingMMPerYear = 1.5;
    fiveYears = 5 * risingMMPerYear;
    sevenYears = 7 * risingMMPerYear;
    tenYears = 10* risingMMPerYear;
    cout<< "In five years, it will be "<< fiveYears<< " millimeters higher than the current ocean's level."<<endl;
    cout<< "In seven years, it will be "<<sevenYears<< " millimeters higher than the current ocean's level."<<endl;
    cout<< "In ten years, it will be "<< tenYears<< " millimeters higher than the current ocean's level."<<endl;
    
    return 0;
}

