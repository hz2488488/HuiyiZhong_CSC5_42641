/* 
 * File:   main.cpp
 * Author: Huiyi Zhong
 * Created on February 27, 2017, 4:00 PM
 * Purpose:  Homework chp2 Q8
 *            
 *          
 */

//System Libraries
#include <iostream> 
using namespace std;


int main(int argc, char** argv) 
{
    double item1, item2, item3, item4, item5;
    double salesTax, subtotal, total, taxPercent; 
    //variables:price of five items, tax, subtotal and total
    item1 = 15.95;
    item2 = 24.95;
    item3 = 6.95;
    item4 = 12.95;
    item5 = 3.95;
    //price of each item
    taxPercent = 0.07;
            subtotal = item1 + item2 + item3 + item4 + item5;
            salesTax = subtotal * taxPercent;
            total = subtotal + salesTax;
            cout<< "Price of item1: $"<< item1 <<endl;
            cout<< "Price of item2: $"<< item2 <<endl;
            cout<< "Price of item3: $"<< item3 << endl;
            cout<< "Price of item4: $"<< item4 << endl;
            cout<< "Price of item5: $"<< item5 << endl;
            cout<<"subtotal of the sale: $" << subtotal << endl;
            cout<< "amount of sales tax: $"<< salesTax << endl;
            cout<< "total: $"<< total << endl;
    return 0;
}