/* 
 * File:   main.cpp
 * Author: Huiyi Zhong
 * Created on February 27, 2017, 4:00 PM
 * Purpose:  Homework chp2 Q3
 *            
 *          
 */

//System Libraries
#include <iostream> 
using namespace std;


int main(int argc, char** argv) {
   double purchase, statetax, countytax, totalSalesTax;
    purchase = 95;
    statetax = 0.04;
    countytax = 0.02;
    totalSalesTax = purchase * statetax + purchase * countytax;
    cout<< "Total sales tax on a $95 purchase will be $" << totalSalesTax << ",including both state and county tax" ;
    return 0;
}

