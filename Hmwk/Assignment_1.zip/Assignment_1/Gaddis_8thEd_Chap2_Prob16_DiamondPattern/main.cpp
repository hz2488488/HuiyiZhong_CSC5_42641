/* 
 * File:   main.cpp
 * Author: Huiyi Zhong
 * Created on February 28, 2017, 10:45 AM
 * Purpose:  Homework of chpt2 Q16
 *           
 *          
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

int main(int argc, char** argv) {
    cout<< "   *   "<<endl;
    cout<< "  ***  "<<endl;
    cout<< " ***** "<<endl;
    cout<< "*******"<<endl;
    cout<< " ***** "<<endl;
    cout<< "  ***  "<<endl;
    cout<< "   *   "<<endl;
    return 0;
}

