/* 
 * File:   main.cpp
 * Author: Huiyi Zhong
 * Created on February 27, 2017, 4:00 PM
 * Purpose:  Homework chp2 Q2
 *            
 *          
 */

//System Libraries
#include <iostream> 
using namespace std;


int main(int argc, char** argv) {
    double generates;
    float sales;
    sales = 8600000;
    generates = 0.58*sales;
    cout<< "the East Coast division will generate$" <<generates << "if the company has $8.6 million in sales this year.";
    return 0;
}

