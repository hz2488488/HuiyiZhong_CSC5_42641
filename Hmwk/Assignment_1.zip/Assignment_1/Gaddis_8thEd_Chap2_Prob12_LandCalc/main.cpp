/* 
 * File:   main.cpp
 * Author: Huiyi Zhong
 * Created on February 27, 2017, 4:00 PM
 * Purpose:  Homework chp2 Q12
 *            
 *          
 */

//System Libraries
#include <iostream> 
using namespace std;


int main(int argc, char** argv) 
{
    double acres, squareFeet;
    squareFeet = 391876;
    acres = squareFeet / 43560; //the conversion formula
    cout<< "In a tract of land with 391,876 square feet, there are " << acres << " acres." << endl;
    return 0;
}