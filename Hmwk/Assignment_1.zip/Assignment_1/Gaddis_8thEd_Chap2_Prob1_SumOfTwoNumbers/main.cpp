/* 
 * File:   main.cpp
 * Author: Huiyi Zhong
 * Created on February 27, 2017, 4:00 PM
 * Purpose:  Homework chp2 Q1
 *            
 *          
 */

//System Libraries
#include <iostream> 
using namespace std;


int main(int argc, char** argv) 
{
    int firstNumber, secondNumber, total;
    firstNumber = 50;
    secondNumber = 100;
    total = firstNumber + secondNumber; //sum of 50 and 100
    cout<< "the sum of 50 and 100 is total:"<<total;
    return 0;
}