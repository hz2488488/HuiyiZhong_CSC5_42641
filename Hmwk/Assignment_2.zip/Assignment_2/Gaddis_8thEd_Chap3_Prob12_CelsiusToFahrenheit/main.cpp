/* 
 * File:   main.cpp
 * Author: Huiyi Zhong
 * Created on March 09, 2017, 1:30 PM
 * Purpose: Convert Celsius to Fahrenheit
 */

//System Libraries
#include <iostream>
#include <iomanip> //Input - Output Library
using namespace std; //Name-space under which system libraries exist

int main(int argc, char** argv) {
    float fahrenheit, celsius; //assign variables
    cout<< "Please type the Celsuis temperatures here:"<<endl;
    cin>>celsius;
    fahrenheit = 9 / 5 * celsius + 32; //convertion formula  
    cout<<celsius<<" Celsuis temperatures equals to "<<fahrenheit<<" Fahrenheit temperatures"<<endl;

    
    
    
    
   
    
    
    //Exit stage right!
    return 0;
}

