/* 
 * File:   main.cpp
 * Author: Huiyi Zhong
 * Created on March 09, 2017, 1:30 PM
 * Purpose: Find test average
 */

//System Libraries
#include <iostream>
#include <iomanip> //Input - Output Library
using namespace std; //Name-space under which system libraries exist

int main(int argc, char** argv) {
    
    float firstTest, secondTest,thirdTest, fourthTest, fifthTest;  //Declare variables, five test score
    cout<<"What is the score for the first test?"<<endl;
    cin>>firstTest; //input data
    cout<<"What is the score for the second test?"<<endl;
    cin>>secondTest;//Input data
    cout<<"What is the score for the third test?"<<endl;
    cin>>thirdTest;
    cout<<"What is the score for the fourth test?"<<endl;
    cin>>fourthTest;
    cout<<"What is the score for the fifth test?"<<endl;
    cin>>fifthTest;
    cout<<"The average test score is ";
    cout<<((firstTest + secondTest + thirdTest + fourthTest + fifthTest)/5)<<setprecision(1)<<fixed<<endl;
    
    

    
    
    
    
   
    
    
    //Exit stage right!
    return 0;
}

