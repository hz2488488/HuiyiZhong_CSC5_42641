/* 
 * File:   main.cpp
 * Author: Huiyi Zhong
 * Created on March 09, 2017, 1:30 PM
 * Purpose: word game
 */

//System Libraries
#include <iostream>

using namespace std; //Name-space under which system libraries exist

int main(int argc, char** argv) {
    string name,age,city,college,profession,pet,petsname;
    cout<<"What is your name?"<<endl;
    cin>>name;//input
    cout<<"How old are you?"<<endl;
    cin>>age;//input
    cout<<"Type a name of a city"<<endl;
    cin>>city;//input
    cout<<"Type a name of a college"<<endl;
    cin>>college;//input
    cout<<"Type a profession"<<endl;
    cin>>profession;//input
    cout<<"Type a type of animal"<<endl;
    cin>>pet;//input
    cout<<"Type a pet's name"<<endl;
    cin>>petsname;//input
    cout<<"There once was a person named "<<name<<" who lived in "<<city<<". At the age of "<<endl;
    cout<<age<<" ,"<<name<<" went to college at "<<college<<". "<<name<<" graduated and went to work"<<endl;
    cout<<"as a "<<profession<<". Then,"<<name<<" adopted a "<<pet<<" named "<<petsname<<". They"<<endl;
    cout<<"both lived happily ever after!";//output
    
    
    
    
   
    
    
    //Exit stage right!
    return 0;
}

