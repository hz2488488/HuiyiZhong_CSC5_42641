/* 
 * File:   main.cpp
 * Author: Huiyi Zhong
 * Created on March 09, 2017, 1:30 PM
 * Purpose: calculate insurance
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std; //Name-space under which system libraries exist

int main(int argc, char** argv) {
    float replacement, insurance; //assign variables
    cout<< "How much does it cost to replace the house?"<<endl;
    cin>>replacement;//input
    insurance = replacement * 0.8; //process
            cout<<"The minimum amount insurance you should buy will be ";
            cout<<setprecision(2)<<fixed;
    cout<<"$"<<insurance<<endl;
    
    
    
    
   
    
    
    //Exit stage right!
    return 0;
}

