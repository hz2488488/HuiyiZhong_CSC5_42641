/* 
 * File:   main.cpp
 * Author: Huiyi Zhong
 * Created on March 09, 2017, 1:30 PM
 * Purpose:  Stadium probi
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

int main(int argc, char** argv) {
    float miles, gallons; //Declare variables
    cout<<"How many gallons of gas the car can hold?"<< endl;
    cin>>gallons;//Input data
    cout<<"How many miles it can be driven on a full tank?"<< endl;
    cin>>miles;//Input data
    cout<<"The gas mileage of the car is "<<(miles / gallons)<<" miles/gallon"<<endl; //Process the data and output
    
    
    
    
   
    
    
    //Exit stage right!
    return 0;
}

