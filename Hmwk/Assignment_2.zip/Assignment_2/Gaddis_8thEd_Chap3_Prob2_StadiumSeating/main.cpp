/* 
 * File:   main.cpp
 * Author: Huiyi Zhong
 * Created on March 09, 2017, 1:30 PM
 * Purpose:  Stadium income from selling seats.
 */

//System Libraries
#include <iostream>
#include <iomanip> //Input - Output Library
using namespace std; //Name-space under which system libraries exist

int main(int argc, char** argv) {
    float a,b,c, incomeA,incomeB,incomeC;  //Declare variables
    cout<<"How many Class A ticket has been sold?"<< endl;
    cin>>a; //input data
    cout<<"How many Class B ticket has been sold?"<< endl;
    cin>>b;//Input data
    cout<<"How many Class C ticket has been sold?"<< endl;
    cin>>c;
    incomeA = a * 15.00; //15 dollars per ticket
    incomeB = b * 12.00; //12 dollars per ticket
    incomeC = c * 9.00; // 9 dolloars per ticket
    cout<<"The total amount of income generated from tickets sales is $";
    
    cout<<setprecision(2)<<fixed<<showpoint;
    cout<<(incomeA + incomeB + incomeC)<<endl; //Process the data and output
    
  
    
    
    
    
   
    
    
    //Exit stage right!
    return 0;
}

