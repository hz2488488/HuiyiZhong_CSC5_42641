/* 
 * File:   main.cpp
 * Author: Huiyi Zhong
 * Created on March 09, 2017, 1:30 PM
 * Purpose: Find how many widgets on the pallet
 */

//System Libraries
#include <iostream>
#include <iomanip> //Input - Output Library
using namespace std; //Name-space under which system libraries exist

int main(int argc, char** argv) {
    const float widgets = 12.5; //Each widgets weight.
    float palletWeight, totalWeight;//assigned variables
    cout<<"what is the weight of the pallet?"<<endl;
    cin>> palletWeight; //input
    cout<<"What is the total weight after stacking the widgets?"<<endl;
    cin>>totalWeight; //input 
    cout<<"The number of widgets stacked on the pallet is ";
    cout<<((totalWeight - palletWeight) / widgets) <<endl;
    

    
    
    
    
   
    
    
    //Exit stage right!
    return 0;
}

