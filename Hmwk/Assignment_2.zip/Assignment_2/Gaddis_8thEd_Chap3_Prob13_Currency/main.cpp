/* 
 * File:   main.cpp
 * Author: Huiyi Zhong
 * Created on March 09, 2017, 1:30 PM
 * Purpose: Convert dollars to yen and euros
 */

//System Libraries
#include <iostream>

using namespace std; //Name-space under which system libraries exist

int main(int argc, char** argv) {
    const float YEN_PER_DOLLAR = 98.93, EUROS_PER_DOLLAR = 0.74;
    float usdollar,yen,euros;
    cout<<"how much US dollar do you have?"<<endl;
    cin>>usdollar;
    yen = usdollar * YEN_PER_DOLLAR;
    euros = usdollar * EUROS_PER_DOLLAR;
    cout<<"$"<<usdollar<<" equals to "<<yen<<" Yen or "<<euros<<" Euros"<<endl;

    
    
    
    
   
    
    
    //Exit stage right!
    return 0;
}

