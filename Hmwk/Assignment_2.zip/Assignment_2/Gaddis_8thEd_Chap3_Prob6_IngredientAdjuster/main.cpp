/* 
 * File:   main.cpp
 * Author: Huiyi Zhong
 * Created on March 09, 2017, 1:30 PM
 * Purpose: Find the ingredients for making cookies
 */

//System Libraries
#include <iostream>
#include <iomanip> //Input - Output Library
using namespace std; //Name-space under which system libraries exist

int main(int argc, char** argv) {
    const int cookie = 48;//one recipe can make 48 cookies with the given amount of the ingredients
    float cookies,sugar, butter, flour;  //Declare variables
    sugar = 1.5; //1.5cups for 48 cookies
    butter = 1; //1 cup for 48 cookies
    flour = 2.75; //2.78 cups for 48 cookies
    cout<<"How many cookies are you going to make?"<<endl;
    cin>>cookies; //input data
    sugar = sugar * (cookies/cookie);
    butter = butter * (cookies/cookie);
    flour = flour * (cookies/cookie);
    cout<<"To make "<<cookies<< " cookies, you need: "<<endl;
    cout<<sugar<<" cups of sugar"<<endl;
    cout<<butter<<" cups of butter"<<endl;
    cout<<flour<<" cups of flour"<<endl;

    

    
    
    
    
   
    
    
    //Exit stage right!
    return 0;
}

