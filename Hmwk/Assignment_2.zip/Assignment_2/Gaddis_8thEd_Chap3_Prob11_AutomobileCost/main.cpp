/* 
 * File:   main.cpp
 * Author: Huiyi Zhong
 * Created on March 09, 2017, 1:30 PM
 * Purpose: automobile cost
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std; //Name-space under which system libraries exist

int main(int argc, char** argv) {
    float loan, insurance, gas, oil, tires, maintenance,monthly,annually;//assign variables
    cout<<"What is the amount you spend on loan each month?"<<endl;
    cin>>loan; //input
    cout<<"How much is your insurance each month?"<<endl;
    cin>>insurance;//input
    cout<<"How much do you spend on gas each month?"<<endl;
    cin>>gas;//input
    cout<<"How much do you spend on tires each month?"<<endl;
    cin>>tires;//input
    cout<<"How much do you spend on maintenance each month?"<<endl;
    cin>>maintenance;//input
    monthly = loan + insurance + gas + tires + maintenance;//process
    annually = monthly * 12; //12months = 1 year
    cout<<setprecision(2)<<fixed;
    cout<< "The total monthly cost is $"<<monthly<<endl; //output
    cout<< "The total annually cost is $"<<annually<<endl;//output

    
    
    
    
   
    
    
    //Exit stage right!
    return 0;
}

